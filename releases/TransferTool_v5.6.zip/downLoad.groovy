import com.urbancode.air.AirPluginTool;
import com.urbancode.air.CommandHelper;

def apTool = new AirPluginTool(this.args[0], this.args[1])
def props = apTool.getStepProperties();

def udclientP = props['udclientPath'];
def url = props['url'];
def user = props['user'];
def pass = props['pass'];
def downloadPath = props['downloadPath'];
def component = props['component'];
def vName = props['vName'];
def includes = props['includes'];
def excludes = props['excludes'];
def zipFile = "${downloadPath}/${component}_${vName}_artifacts.zip"
def udclient = "$udclientP/udclient"

//Download Version
println "Descargar desde version $vName"
def crtVer= ["$udclient","-weburl", url,"-username", user,"-password", pass,"downloadVersionArtifacts","-component", component,"-name", vName,"-version", vName,"-location", downloadPath,"--verbose"].execute().text
println crtVer


//Unzip Version
def builder = new AntBuilder()
builder.unzip(src:"${zipFile}", dest:".", overwrite:true)


//Set an output property
apTool.setOutputProperty("Downloaded package", "$zipFile");
//apTool.setOutputProperty("Load files", loadV);

apTool.storeOutputProperties();//write the output properties to the file